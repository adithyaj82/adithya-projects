//
//  Photo+CoreDataClass.swift
//  CoreDataTutorialPart1Final
//
//  Created by James Rochabrun on 3/1/17.
//  Copyright © 2017 James Rochabrun. All rights reserved.
//

import Foundation
import CoreData


public class Photo: NSManagedObject {

}
