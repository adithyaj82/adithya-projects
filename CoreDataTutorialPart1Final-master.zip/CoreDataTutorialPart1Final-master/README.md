# CoreDataTutorialPart1Final
Final project of CoreData tutorial part 1

https://medium.com/@jamesrochabrun/parsing-json-response-and-save-it-in-coredata-step-by-step-fb58fc6ce16f

![jcd](https://user-images.githubusercontent.com/5378604/48667165-3e34d580-ea85-11e8-8e2c-ba58a3b2ecc6.png)
