//
//  CollectionViewCell.swift
//  puzzle3
//
//  Created by adithya on 12/3/18.
//  Copyright © 2018 akhil. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var l1: UILabel!
    
}
