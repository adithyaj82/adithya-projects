//
//  ViewController2.swift
//  puzzle3
//
//  Created by adithya on 12/2/18.
//  Copyright © 2018 akhil. All rights reserved.
//

import UIKit

class ViewController2: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource{
    
    let number = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20"]
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return number.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)as! CollectionViewCell
        cell.l1.text = number[indexPath.row]
        cell.l1.layer.shadowOffset = CGSize(width: 1, height: 5)
        cell.l1.layer.shadowRadius = 2.0
        cell.l1.layer.shadowOpacity = 1
        cell.l1.layer.masksToBounds = false
        cell.l1.layer.borderWidth = 1
        cell.l1.layer.cornerRadius=5;

        
        cell.layer.shadowOffset = CGSize(width: 1, height: 5)
        cell.layer.shadowRadius = 2.0
        cell.layer.shadowOpacity = 1
        cell.layer.masksToBounds = false
        collectionView.clipsToBounds = false
        cell.layer.borderWidth = 1
        cell.layer.cornerRadius=5;
        cell.backgroundColor = UIColor.white
        cell.layer.backgroundColor = UIColor.init(red:196/255.0, green:227/255.0, blue:245/255.0, alpha: 1.0).cgColor
        return cell
    }
  
    //var   aaaa = [[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8],[1,0,2,3,4,5,6,7,8]]

    var a = [[#imageLiteral(resourceName: "Layer 1"), #imageLiteral(resourceName: "Layer 3"), #imageLiteral(resourceName: "Layer 6"), #imageLiteral(resourceName: "Layer 4"), #imageLiteral(resourceName: "Layer 5"), #imageLiteral(resourceName: "Layer 7"), #imageLiteral(resourceName: "Layer 8"), #imageLiteral(resourceName: "Layer 9"), #imageLiteral(resourceName: "Layer 10")],
             [ #imageLiteral(resourceName: "1544375692897.jpg"), #imageLiteral(resourceName: "1544375693963.jpg"), #imageLiteral(resourceName: "1544375695127.jpg"), #imageLiteral(resourceName: "1544375695821.jpg"), #imageLiteral(resourceName: "1544375697107.jpg"), #imageLiteral(resourceName: "1544375698126.jpg"), #imageLiteral(resourceName: "1544375698964.jpg"), #imageLiteral(resourceName: "1544375700004.jpg"), #imageLiteral(resourceName: "1544375701898.jpg")],
             [ #imageLiteral(resourceName: "1544375753099.jpg"),#imageLiteral(resourceName: "1544375753490.jpg"),#imageLiteral(resourceName: "1544375753879.jpg"),#imageLiteral(resourceName: "1544375754184.jpg"),#imageLiteral(resourceName: "1544375754595.jpg"),#imageLiteral(resourceName: "1544375754986.jpg"),#imageLiteral(resourceName: "1544375755309.jpg"),#imageLiteral(resourceName: "1544375755561.jpg"),#imageLiteral(resourceName: "1544375755952.jpg")],
             [#imageLiteral(resourceName: "1544377816288.jpg"),#imageLiteral(resourceName: "1544377816616.jpg"),#imageLiteral(resourceName: "1544377816827.jpg"),#imageLiteral(resourceName: "1544377817123.jpg"),#imageLiteral(resourceName: "1544377817449.jpg"),#imageLiteral(resourceName: "1544377817667.jpg"),#imageLiteral(resourceName: "1544377817892.jpg"),#imageLiteral(resourceName: "1544377818156.jpg"),#imageLiteral(resourceName: "1544377818401.jpg")],
             [  #imageLiteral(resourceName: "1544378374436.jpg"),#imageLiteral(resourceName: "1544378374688.jpg"),#imageLiteral(resourceName: "1544378374936.jpg"),#imageLiteral(resourceName: "1544378375152.jpg"),#imageLiteral(resourceName: "1544378375506.jpg"),#imageLiteral(resourceName: "1544378375784.jpg"),#imageLiteral(resourceName: "1544378376026.jpg"),#imageLiteral(resourceName: "1544378376236.jpg"),#imageLiteral(resourceName: "1544378376441.jpg")],
             [ #imageLiteral(resourceName: "1544377870780.jpg"),#imageLiteral(resourceName: "1544377870989.jpg"),#imageLiteral(resourceName: "1544377871254.jpg"),#imageLiteral(resourceName: "1544377871525.jpg"),#imageLiteral(resourceName: "1544377871716.jpg"),#imageLiteral(resourceName: "1544377871921.jpg"),#imageLiteral(resourceName: "1544377872118.jpg"),#imageLiteral(resourceName: "1544377872325.jpg"),#imageLiteral(resourceName: "1544377872532.jpg")],
             
             [#imageLiteral(resourceName: "1544377898891.jpg"),#imageLiteral(resourceName: "1544377899062.jpg"),#imageLiteral(resourceName: "1544377899315.jpg"),#imageLiteral(resourceName: "1544377899493.jpg"),#imageLiteral(resourceName: "1544377899669.jpg"),#imageLiteral(resourceName: "1544377899842.jpg"),#imageLiteral(resourceName: "1544377900008.jpg"),#imageLiteral(resourceName: "1544377900219.jpg"),#imageLiteral(resourceName: "1544377900390.jpg")],
             [#imageLiteral(resourceName: "1544377947522.jpg"),#imageLiteral(resourceName: "1544377947776.jpg"),#imageLiteral(resourceName: "1544377948143.jpg"),#imageLiteral(resourceName: "1544377948478.jpg"),#imageLiteral(resourceName: "1544377948826.jpg"),#imageLiteral(resourceName: "1544377949058.jpg"),#imageLiteral(resourceName: "1544377949319.jpg"),#imageLiteral(resourceName: "1544377949638.jpg"),#imageLiteral(resourceName: "1544377949873.jpg")],
             [ #imageLiteral(resourceName: "1544377982972.jpg"),#imageLiteral(resourceName: "1544377983123.jpg"),#imageLiteral(resourceName: "1544377983335.jpg"),#imageLiteral(resourceName: "1544377983576.jpg"),#imageLiteral(resourceName: "1544377983849.jpg"),#imageLiteral(resourceName: "1544377984110.jpg"),#imageLiteral(resourceName: "1544377984371.jpg"),#imageLiteral(resourceName: "1544377984603.jpg"),#imageLiteral(resourceName: "1544377984843.jpg")],
             [ #imageLiteral(resourceName: "1544378016427.jpg"),#imageLiteral(resourceName: "1544378016603.jpg"),#imageLiteral(resourceName: "1544378016864.jpg"),#imageLiteral(resourceName: "1544378017052.jpg"),#imageLiteral(resourceName: "1544378017244.jpg"),#imageLiteral(resourceName: "1544378017476.jpg"),#imageLiteral(resourceName: "1544378017766.jpg"),#imageLiteral(resourceName: "1544378017981.jpg"),#imageLiteral(resourceName: "1544378018217.jpg")],
             [ #imageLiteral(resourceName: "1544378039736.jpg"),#imageLiteral(resourceName: "1544378039900.jpg"),#imageLiteral(resourceName: "1544378040179.jpg"),#imageLiteral(resourceName: "1544378040386.jpg"),#imageLiteral(resourceName: "1544378040582.jpg"),#imageLiteral(resourceName: "1544378040792.jpg"),#imageLiteral(resourceName: "1544378041016.jpg"),#imageLiteral(resourceName: "1544378041307.jpg"),#imageLiteral(resourceName: "1544378041528.jpg")],
             [ #imageLiteral(resourceName: "1544378058889.jpg"),#imageLiteral(resourceName: "1544378059137.jpg"),#imageLiteral(resourceName: "1544378059351.jpg"),#imageLiteral(resourceName: "1544378059608.jpg"),#imageLiteral(resourceName: "1544378059825.jpg"),#imageLiteral(resourceName: "1544378060057.jpg"),#imageLiteral(resourceName: "1544378060303.jpg"),#imageLiteral(resourceName: "1544378060602.jpg"),#imageLiteral(resourceName: "1544378060835.jpg")],
             [ #imageLiteral(resourceName: "1544378082972.jpg"),#imageLiteral(resourceName: "1544378083172.jpg"),#imageLiteral(resourceName: "1544378083545.jpg"),#imageLiteral(resourceName: "1544378083782.jpg"),#imageLiteral(resourceName: "1544378084095.jpg"),#imageLiteral(resourceName: "1544378084307.jpg"),#imageLiteral(resourceName: "1544378084529.jpg"),#imageLiteral(resourceName: "1544378084727.jpg"),#imageLiteral(resourceName: "1544378084980.jpg")],
             [ #imageLiteral(resourceName: "1544378118106.jpg"),#imageLiteral(resourceName: "1544378118259.jpg"),#imageLiteral(resourceName: "1544378118482.jpg"),#imageLiteral(resourceName: "1544378118736.jpg"),#imageLiteral(resourceName: "1544378118995.jpg"),#imageLiteral(resourceName: "1544378119268.jpg"),#imageLiteral(resourceName: "1544378119496.jpg"),#imageLiteral(resourceName: "1544378119706.jpg"),#imageLiteral(resourceName: "1544378119941.jpg")],
             [  #imageLiteral(resourceName: "1544378166787.jpg"),#imageLiteral(resourceName: "1544378166998.jpg"),#imageLiteral(resourceName: "1544378171877.jpg"),#imageLiteral(resourceName: "1544378172149.jpg"),#imageLiteral(resourceName: "1544378172473.jpg"),#imageLiteral(resourceName: "1544378172755.jpg"),#imageLiteral(resourceName: "1544378173031.jpg"),#imageLiteral(resourceName: "1544378173264.jpg"),#imageLiteral(resourceName: "1544378173539.jpg")],
             [  #imageLiteral(resourceName: "1544378203700.jpg"),#imageLiteral(resourceName: "1544378203885.jpg"),#imageLiteral(resourceName: "1544378204128.jpg"),#imageLiteral(resourceName: "1544378204338.jpg"),#imageLiteral(resourceName: "1544378204545.jpg"),#imageLiteral(resourceName: "1544378204767.jpg"),#imageLiteral(resourceName: "1544378205006.jpg"),#imageLiteral(resourceName: "1544378205213.jpg"),#imageLiteral(resourceName: "1544378205433.jpg")],
             [  #imageLiteral(resourceName: "1544378229811.jpg"),#imageLiteral(resourceName: "1544378230017.jpg"),#imageLiteral(resourceName: "1544378230266.jpg"),#imageLiteral(resourceName: "1544378230458.jpg"),#imageLiteral(resourceName: "1544378230687.jpg"),#imageLiteral(resourceName: "1544378230898.jpg"),#imageLiteral(resourceName: "1544378231137.jpg"),#imageLiteral(resourceName: "1544378231516.jpg"),#imageLiteral(resourceName: "1544378231797.jpg")],
             [  #imageLiteral(resourceName: "1544378249333.jpg"),#imageLiteral(resourceName: "1544378249533.jpg"),#imageLiteral(resourceName: "1544378249932.jpg"),#imageLiteral(resourceName: "1544378250202.jpg"),#imageLiteral(resourceName: "1544378250479.jpg"),#imageLiteral(resourceName: "1544378250792.jpg"),#imageLiteral(resourceName: "1544378251040.jpg"),#imageLiteral(resourceName: "1544378251359.jpg"),#imageLiteral(resourceName: "1544378251621.jpg")],
             [  #imageLiteral(resourceName: "1544378283869.jpg"),#imageLiteral(resourceName: "1544378284044.jpg"),#imageLiteral(resourceName: "1544378284255.jpg"),#imageLiteral(resourceName: "1544378284489.jpg"),#imageLiteral(resourceName: "1544378284758.jpg"),#imageLiteral(resourceName: "1544378284982.jpg"),#imageLiteral(resourceName: "1544378285222.jpg"),#imageLiteral(resourceName: "1544378285429.jpg"),#imageLiteral(resourceName: "1544378285632.jpg")],
             [  #imageLiteral(resourceName: "1544378315443.jpg"),#imageLiteral(resourceName: "1544378315635.jpg"),#imageLiteral(resourceName: "1544378315873.jpg"),#imageLiteral(resourceName: "1544378316099.jpg"),#imageLiteral(resourceName: "1544378316323.jpg"),#imageLiteral(resourceName: "1544378316518.jpg"),#imageLiteral(resourceName: "1544378316736.jpg"),#imageLiteral(resourceName: "1544378316981.jpg"),#imageLiteral(resourceName: "1544378317206.jpg")]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
  
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        vc.aaa = a[indexPath.row]
        vc.lvlstage = number[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
  
}
