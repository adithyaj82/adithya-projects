//
// Copyright (c) 2016 Rafał Sroka
//
// Licensed under the GNU General Public License, Version 3.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at:
//
//   https://www.gnu.org/licenses/gpl-3.0.en.html
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
                            
    var window: UIWindow?

    private func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        let defaults = UserDefaults.standard
        let skipTutorialPages = defaults.bool(forKey: "skipTutorialPages")
        
        if skipTutorialPages
        {
            let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            
            let nextView: GameViewController = mainStoryboard.instantiateViewController(withIdentifier: "GameViewController") as! GameViewController
            
            window?.rootViewController = nextView
            
        } else {
           // UIPageControl.appearance().pageIndicatorTintColor = UIColor.lightGray
          //  UIPageControl.appearance().currentPageIndicatorTintColor = UIColor.red
        }
        
        
        
        return true
    }

}
