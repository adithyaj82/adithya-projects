//
//  ViewController0.swift
//  jsonGet
//
//  Created by adithya on 12/17/18.
//  Copyright © 2018 rajendra reddy. All rights reserved.
//

import UIKit

class ViewController0: UIViewController, UITableViewDelegate,UITableViewDataSource  {
    @IBOutlet var tableview: UITableView!
    var dfdf = ["Animals","Nature","City"]
    var df = ["https://mymodernmet.com/wp/wp-content/uploads/2017/01/animal-selfies-5.jpg","https://iso.500px.com/wp-content/uploads/2014/07/big-one.jpg","https://d2v9y0dukr6mq2.cloudfront.net/video/thumbnail/N3oOEwywx/beautiful-aerial-view-of-futuristic-city-landscape-with-roads-cars-trains-skyscrapers-dubai-uae_sl6kshxcg_thumbnail-full01.png"]
    var nameArray = [[
        "https://mymodernmet.com/wp/wp-content/uploads/2017/01/animal-selfies-5.jpg"
        ,"https://www.the-tls.co.uk/s3/tls-prod/uploads/2017/02/White-Fang.jpg"
        ,"http://r.ddmcdn.com/s_f/o_1/APL/uploads/2014/10/moms0.jpg"
        ,"http://kb4images.com/images/animals-picture/36913440-animals-picture.jpg"
        ,"http://www.prolocoamandola.org/wp-content/uploads/2018/01/golden-hamster-1024x678.jpg"],["https://iso.500px.com/wp-content/uploads/2014/07/big-one.jpg","https://static.boredpanda.com/blog/wp-content/uploads/2015/11/reflection-landscape-photography-jaewoon-u-fb.jpg","https://static.photocdn.pt/images/articles/2017_1/iStock-545347988.jpg","https://3c1703fe8d.site.internapcdn.net/newman/gfx/news/hires/2018/rusticlandsc.jpg","https://cdn.photographylife.com/wp-content/uploads/2016/06/Mass.jpg","https://forestsnews.cifor.org/wp-content/uploads/2014/12/integrated-rice-and-fish-farms-anirban-mahapatra-1024x767.jpg","https://cdn.fstoppers.com/styles/large-16-9/s3/lead/2018/06/ultra-wide-mistakes-lead-image.jpg","https://mymodernmet.com/wp/wp-content/uploads/2018/08/albert-dros-kyrgyzstan-1.jpg","http://illes-balears-cms-subsections.s3.amazonaws.com/patrimoni-natural.jpg","http://landscaping.net.au/wp-content/uploads/2017/07/Cat-19-F-Honeywood2.jpg","https://i.pinimg.com/originals/5c/4b/67/5c4b672e04cc92914959cc8e9e8125c7.jpg"],["https://d2v9y0dukr6mq2.cloudfront.net/video/thumbnail/N3oOEwywx/beautiful-aerial-view-of-futuristic-city-landscape-with-roads-cars-trains-skyscrapers-dubai-uae_sl6kshxcg_thumbnail-full01.png","https://upload.wikimedia.org/wikipedia/commons/8/84/City_landscape_of_Darwin%2C_Northern_Territory.jpg","https://images.fineartamerica.com/images/artworkimages/mediumlarge/1/hong-kong-city-landscape-kam-chuen-dung.jpg","https://www.winnipeglandrover.com/wp-content/uploads/sites/611/2018/05/city-landscape.jpg","https://i.ytimg.com/vi/TAcpZOtmBfw/maxresdefault.jpg","https://www.landscape2art.com/wp-content/uploads/2016/09/oslo-norway-city-landscape.jpg","https://jooinn.com/images/city-landscape-46.jpg","https://jooinn.com/images/city-landscape-14.jpg","https://ak9.picdn.net/shutterstock/videos/10690139/thumb/1.jpg","https://www.wallpaperup.com/uploads/wallpapers/2015/09/26/809920/b6bce4ca78eee16a763cb973e8f18aa1.jpg","http://www.weblight.co.uk/wp-content/uploads/2018/03/canary-wharf-night-london-united-kingdom-city-landscape.jpg","https://jooinn.com/images/city-landscape-38.jpg","https://i.imgur.com/OIOzm.jpg","http://images.china.cn/attachement/jpg/site1007/20171110/c03fd55e71081b6f5e2c10.jpg"]]
    

    // var name = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dfdf.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewCell0
        cell.llb.text = dfdf[indexPath.row]

        let imgURL = NSURL(string: df[indexPath.row])

        if imgURL != nil {
            let data = NSData(contentsOf: (imgURL as URL?)!)
            cell.imgView.image = UIImage(data: data! as Data)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController")as! ViewController
        vc.aaa = nameArray[indexPath.row]
  //      self.navigationController?.pushViewController(vc, animated: true)
        self.present(vc, animated: true, completion: nil)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
    let rotaionTransform = CATransform3DTranslate(CATransform3DIdentity, -500, 10, 0)
    cell.layer.transform = rotaionTransform
        
        UIView.animate(withDuration: 1.0) {
            cell.layer.transform = CATransform3DIdentity

        }
    }
}
