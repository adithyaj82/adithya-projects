//
//  ViewCell0.swift
//  jsonGet
//
//  Created by adithya on 12/17/18.
//  Copyright © 2018 rajendra reddy. All rights reserved.
//

import UIKit

class ViewCell0: UITableViewCell {
    @IBOutlet var llb: UILabel!
    
    @IBOutlet var imgView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
