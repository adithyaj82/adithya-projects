//
//  ViewCell.swift
//  jsonGet
//
//  Created by apple on 3/14/18.
//  Copyright © 2018 rajendra reddy. All rights reserved.
//

import UIKit

class ViewCell: UITableViewCell {
    @IBOutlet var shareButton: UIButton!
    
    @IBOutlet var imgView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
