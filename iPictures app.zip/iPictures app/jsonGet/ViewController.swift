//
//  ViewController.swift
//  jsonGet
//
//  Created by rajendra reddy on 3/9/18.
//  Copyright © 2018 rajendra reddy. All rights reserved.
//

import UIKit

class
ViewController:UIViewController, UITableViewDelegate,UITableViewDataSource {
    @IBOutlet var tableview: UITableView!
    
    var aaa = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aaa.count
    }
    
    @IBAction func bbak(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewCell
        cell.shareButton.tag = indexPath.row
        let imgURL = NSURL(string: aaa[indexPath.row])

        if imgURL != nil {
            let data = NSData(contentsOf: (imgURL as URL?)!)
            cell.imgView.image = UIImage(data: data! as Data)
        }
        
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.size.height;
    }
    
    @IBAction func srs(_ sender: Any) {
        let titleString = self.aaa.index(after: (sender as AnyObject).tag)
        let firstActivityItem = "\(titleString)"
        
        let activity:UIActivityViewController = UIActivityViewController(activityItems: [firstActivityItem], applicationActivities: nil)
        present(activity, animated: true)
        
    }
  
}

